import { Router, type IRouter } from "express";
import {
  CapturePaypalOrderParams,
  CapturePaypalOrderResponse,
  CreatePaypalOrderBody,
  CreatePaypalOrderResponse,
  GetPaypalConfigResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const PAYPAL_API_BASE = "https://api-m.sandbox.paypal.com";

type PayPalAccessTokenResponse = {
  access_token?: string;
};

type PayPalOrderResponse = {
  id?: string;
  status?: string;
  payer?: { email_address?: string };
  purchase_units?: Array<{
    payments?: {
      captures?: Array<{
        id?: string;
        status?: string;
        amount?: { value?: string; currency_code?: string };
      }>;
    };
  }>;
};

function getCredentials(): { clientId: string; clientSecret: string } | null {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  return clientId && clientSecret ? { clientId, clientSecret } : null;
}

async function getAccessToken(): Promise<string> {
  const credentials = getCredentials();
  if (!credentials) {
    throw new Error("PayPal sandbox is not configured.");
  }

  const response = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(
        `${credentials.clientId}:${credentials.clientSecret}`,
      ).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    signal: AbortSignal.timeout(15_000),
  });

  if (!response.ok) {
    throw new Error(`PayPal authentication failed (${response.status}).`);
  }

  const payload = (await response.json()) as PayPalAccessTokenResponse;
  if (!payload.access_token) {
    throw new Error("PayPal did not return an access token.");
  }

  return payload.access_token;
}

router.get("/payments/paypal/config", (_req, res): void => {
  const credentials = getCredentials();
  res.json(
    GetPaypalConfigResponse.parse({
      configured: Boolean(credentials),
      clientId: credentials?.clientId ?? null,
      currency: "USD",
    }),
  );
});

router.post("/payments/paypal/orders", async (req, res): Promise<void> => {
  const parsed = CreatePaypalOrderBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid PayPal order request");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (!getCredentials()) {
    res.status(503).json({
      error: "PayPal sandbox is not configured. Add PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET to Replit Secrets.",
    });
    return;
  }

  try {
    const accessToken = await getAccessToken();
    const response = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [
          {
            reference_id: parsed.data.invoiceNumber.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 32),
            description: `Invoice for ${parsed.data.clientName}`.slice(0, 127),
            amount: {
              currency_code: parsed.data.currency,
              value: parsed.data.totalAmount.toFixed(2),
            },
          },
        ],
      }),
      signal: AbortSignal.timeout(15_000),
    });

    if (!response.ok) {
      req.log.warn({ status: response.status }, "PayPal order creation failed");
      res.status(502).json({ error: "PayPal sandbox could not create the order." });
      return;
    }

    const order = (await response.json()) as PayPalOrderResponse;
    if (!order.id || !order.status) {
      req.log.warn("PayPal returned an incomplete order");
      res.status(502).json({ error: "PayPal sandbox returned an incomplete order." });
      return;
    }

    res
      .status(201)
      .json(CreatePaypalOrderResponse.parse({ id: order.id, status: order.status }));
  } catch (error) {
    req.log.error(
      { error: error instanceof Error ? error.message : "Unknown PayPal error" },
      "PayPal order creation failed",
    );
    res.status(502).json({ error: "PayPal sandbox could not create the order." });
  }
});

router.post(
  "/payments/paypal/orders/:orderId/capture",
  async (req, res): Promise<void> => {
    const params = CapturePaypalOrderParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }

    if (!getCredentials()) {
      res.status(503).json({
        error: "PayPal sandbox is not configured. Add PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET to Replit Secrets.",
      });
      return;
    }

    try {
      const accessToken = await getAccessToken();
      const response = await fetch(
        `${PAYPAL_API_BASE}/v2/checkout/orders/${encodeURIComponent(params.data.orderId)}/capture`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({}),
          signal: AbortSignal.timeout(15_000),
        },
      );

      if (!response.ok) {
        req.log.warn({ status: response.status }, "PayPal order capture failed");
        res.status(502).json({ error: "PayPal sandbox could not capture the order." });
        return;
      }

      const order = (await response.json()) as PayPalOrderResponse;
      const capture = order.purchase_units?.[0]?.payments?.captures?.[0];
      const totalAmount = Number(capture?.amount?.value);
      const currency = capture?.amount?.currency_code;

      if (
        !order.id ||
        !order.status ||
        !Number.isFinite(totalAmount) ||
        currency !== "USD"
      ) {
        req.log.warn("PayPal returned an incomplete capture");
        res.status(502).json({ error: "PayPal sandbox returned an incomplete capture." });
        return;
      }

      res.json(
        CapturePaypalOrderResponse.parse({
          id: capture?.id ?? order.id,
          status: capture?.status ?? order.status,
          totalAmount,
          currency,
          payerEmail: order.payer?.email_address ?? null,
        }),
      );
    } catch (error) {
      req.log.error(
        { error: error instanceof Error ? error.message : "Unknown PayPal error" },
        "PayPal order capture failed",
      );
      res.status(502).json({ error: "PayPal sandbox could not capture the order." });
    }
  },
);

export default router;
