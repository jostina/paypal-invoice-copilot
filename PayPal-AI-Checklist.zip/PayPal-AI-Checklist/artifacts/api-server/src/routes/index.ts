import { Router, type IRouter } from "express";
import healthRouter from "./health";
import invoiceAssistantRouter from "./invoice-assistant";
import paypalRouter from "./paypal";

const router: IRouter = Router();

router.use(healthRouter);
router.use(invoiceAssistantRouter);
router.use(paypalRouter);

export default router;
