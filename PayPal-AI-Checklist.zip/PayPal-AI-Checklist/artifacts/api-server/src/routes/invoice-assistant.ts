import { Router, type IRouter } from "express";
import OpenAI from "openai";
import {
  CreateInvoiceDraftBody,
  CreateInvoiceDraftResponse,
  GetInvoiceAssistantStatusResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/invoice-assistant/status", (_req, res): void => {
  res.json(
    GetInvoiceAssistantStatusResponse.parse({
      configured: Boolean(process.env.OPENAI_API_KEY),
    }),
  );
});

router.post("/invoice-assistant/drafts", async (req, res): Promise<void> => {
  const parsed = CreateInvoiceDraftBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid invoice draft request");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    res.status(503).json({
      error: "AI invoice drafting is not configured. Add OPENAI_API_KEY to Replit Secrets.",
    });
    return;
  }

  const { clientName, workDescription, totalAmount, currency, dueDate } =
    parsed.data;

  try {
    const openai = new OpenAI({ apiKey });
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "Draft professional invoice wording from the user's project notes. Return only a JSON object with string fields: title, lineDescription, paymentTerms, note. Do not invent prices, taxes, fees, dates, or services. Keep title concise, lineDescription specific to the notes, paymentTerms neutral and brief, and note client-friendly. The user must review the result before sending.",
        },
        {
          role: "user",
          content: JSON.stringify({
            clientName,
            workDescription,
            totalAmount,
            currency,
            dueDate: dueDate.toISOString().slice(0, 10),
          }),
        },
      ],
    });

    const content = completion.choices[0]?.message.content;
    if (!content) {
      req.log.warn("AI returned an empty invoice draft");
      res.status(502).json({ error: "AI could not draft this invoice. Please try again." });
      return;
    }

    const generated: unknown = JSON.parse(content);
    if (
      !generated ||
      typeof generated !== "object" ||
      !("title" in generated) ||
      !("lineDescription" in generated) ||
      !("paymentTerms" in generated) ||
      !("note" in generated) ||
      typeof generated.title !== "string" ||
      typeof generated.lineDescription !== "string" ||
      typeof generated.paymentTerms !== "string" ||
      typeof generated.note !== "string"
    ) {
      req.log.warn("AI returned an invalid invoice draft shape");
      res.status(502).json({ error: "AI returned an invalid invoice draft. Please try again." });
      return;
    }

    const response = CreateInvoiceDraftResponse.parse({
      title: generated.title.slice(0, 120),
      lineItems: [
        {
          description: generated.lineDescription.slice(0, 500),
          quantity: 1,
          unitPrice: totalAmount,
        },
      ],
      totalAmount,
      currency,
      dueDate: dueDate.toISOString().slice(0, 10),
      paymentTerms: generated.paymentTerms.slice(0, 300),
      note: generated.note.slice(0, 500),
    });

    res.json(response);
  } catch (error) {
    req.log.error(
      { error: error instanceof Error ? error.message : "Unknown AI error" },
      "Invoice draft generation failed",
    );
    res.status(502).json({
      error: "AI invoice drafting failed. Check the OpenAI configuration and try again.",
    });
  }
});

export default router;
