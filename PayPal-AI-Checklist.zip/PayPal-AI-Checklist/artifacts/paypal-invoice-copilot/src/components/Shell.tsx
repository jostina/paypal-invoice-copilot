import { type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { FileText, LayoutDashboard, Plus, Sparkles } from 'lucide-react';

export function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return (
    <div className="shell">
      <aside className="sidebar">
        <Link href="/" className="brand" data-testid="link-brand">
          <span className="brand-mark">P</span>
          <span><span className="brand-name">PayPal Invoice</span><span className="brand-sub">Copilot workspace</span></span>
        </Link>
        <div className="nav-label">Workspace</div>
        <nav className="nav-links" aria-label="Main navigation">
          <Link href="/" className={`nav-link ${location === '/' ? 'active' : ''}`} data-testid="link-overview"><LayoutDashboard /><span>Overview</span></Link>
          <Link href="/new" className={`nav-link ${location === '/new' ? 'active' : ''}`} data-testid="link-new-invoice"><Plus /><span>New invoice</span></Link>
        </nav>
        <div className="side-bottom">
          <div className="side-note"><strong><Sparkles size={14} style={{ display: 'inline', marginRight: 6, verticalAlign: 'middle' }} />A clearer way to bill</strong><p>Turn the work you did into a thoughtful invoice, then collect securely through PayPal sandbox.</p></div>
          <div className="profile"><span className="profile-avatar">ME</span><span>Freelance studio<small>Local workspace</small></span></div>
        </div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div className="crumb"><FileText size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 7 }} />Invoice workspace</div>
          <div className="top-right"><span className="sandbox-tag">Sandbox mode</span></div>
        </header>
        {children}
      </main>
    </div>
  );
}
