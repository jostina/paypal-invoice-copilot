import { useEffect, useRef, useState } from 'react';
import { useCapturePaypalOrder, useCreatePaypalOrder } from '@workspace/api-client-react';
import type { Invoice } from '../lib/invoices';

declare global {
  interface Window {
    paypal?: {
      Buttons: (options: {
        createOrder: () => Promise<string>;
        onApprove: (data: { orderID: string }) => Promise<void>;
        onError: (error: unknown) => void;
        onCancel?: () => void;
      }) => { render: (container: HTMLElement) => Promise<void>; close?: () => void };
    };
  }
}

export function PaypalCheckout({ invoice, clientId, onPaid, onOrderCreated }: { invoice: Invoice; clientId: string; onPaid: (paidAt: string) => void; onOrderCreated: (orderId: string) => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const orderFn = useCreatePaypalOrder();
  const captureFn = useCapturePaypalOrder();
  const createRef = useRef(orderFn.mutateAsync);
  const captureRef = useRef(captureFn.mutateAsync);
  const paidRef = useRef(onPaid);
  const orderCreatedRef = useRef(onOrderCreated);
  createRef.current = orderFn.mutateAsync;
  captureRef.current = captureFn.mutateAsync;
  paidRef.current = onPaid;
  orderCreatedRef.current = onOrderCreated;
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let disposed = false;
    let buttons: ReturnType<NonNullable<Window['paypal']>['Buttons']> | undefined;
    const target = containerRef.current;
    if (!target) return;
    setError('');
    setLoading(true);
    const sdkUrl = `https://www.paypal.com/sdk/js?client-id=${encodeURIComponent(clientId)}&currency=${encodeURIComponent(invoice.currency)}&intent=capture`;
    const existing = document.querySelector<HTMLScriptElement>('script[data-paypal-sdk="invoice-copilot"]');
    const script = existing ?? document.createElement('script');
    const renderButtons = async () => {
      if (disposed || !window.paypal || !containerRef.current) return;
      try {
        buttons = window.paypal.Buttons({
          createOrder: async () => {
            const order = await createRef.current({ data: {
              invoiceNumber: invoice.invoiceNumber,
              clientName: invoice.clientName,
              totalAmount: invoice.totalAmount,
              currency: invoice.currency,
            } });
            orderCreatedRef.current(order.id);
            return order.id;
          },
          onApprove: async (data) => {
            try {
              const captured = await captureRef.current({ orderId: data.orderID });
              const amountMatches = Math.abs(captured.totalAmount - invoice.totalAmount) < 0.005;
              if (
                captured.status.toUpperCase() === 'COMPLETED' &&
                captured.currency === invoice.currency &&
                amountMatches
              ) {
                paidRef.current(new Date().toISOString());
              } else {
                setError(`PayPal returned ${captured.status} for ${captured.totalAmount.toFixed(2)} ${captured.currency}. The invoice has not been marked paid.`);
              }
            } catch {
              setError('PayPal approval was received, but capture could not be confirmed. Check the payment status before retrying.');
            }
          },
          onError: () => setError('PayPal sandbox could not complete this checkout. Check your configuration and try again.'),
          onCancel: () => setError('Checkout was cancelled. No payment was captured.'),
        });
        await buttons.render(containerRef.current);
        if (!disposed) setLoading(false);
      } catch {
        if (!disposed) { setLoading(false); setError('PayPal checkout could not be loaded. Confirm your sandbox client ID and try again.'); }
      }
    };
    if (window.paypal) void renderButtons();
    else {
      script.src = sdkUrl;
      script.async = true;
      script.dataset.paypalSdk = 'invoice-copilot';
      script.onload = () => void renderButtons();
      script.onerror = () => { if (!disposed) { setLoading(false); setError('PayPal sandbox SDK could not be loaded. Check your connection and configuration.'); } };
      if (!existing) document.head.appendChild(script);
    }
    return () => {
      disposed = true;
      buttons?.close?.();
      if (target) target.replaceChildren();
    };
  }, [clientId, invoice.currency, invoice.invoiceNumber, invoice.clientName, invoice.totalAmount]);

  return <div>
    {loading && <div className="loading-skeleton" style={{ width: 190, height: 40, marginBottom: 10 }} aria-label="Loading PayPal checkout" />}
    <div className="paypal-buttons" ref={containerRef} data-testid="paypal-sdk-buttons" />
    {error && <div className="alert alert-error" role="alert" style={{ marginTop: 12, marginBottom: 0 }} data-testid="status-paypal-error">{error}</div>}
  </div>;
}
