export type InvoiceStatus = 'draft' | 'sent' | 'paid';
export type LineItem = { description: string; quantity: number; unitPrice: number };
export type Invoice = {
  id: string;
  invoiceNumber: string;
  clientName: string;
  title: string;
  lineItems: LineItem[];
  totalAmount: number;
  currency: 'USD';
  dueDate: string;
  paymentTerms: string;
  note: string;
  status: InvoiceStatus;
  createdAt: string;
  paypalOrderId?: string;
  paidAt?: string;
};
const STORAGE_KEY = 'invoice-copilot-invoices-v1';
export function readInvoices(): Invoice[] {
  try {
    const value = localStorage.getItem(STORAGE_KEY);
    return value ? JSON.parse(value) as Invoice[] : [];
  } catch {
    return [];
  }
}
export function writeInvoices(invoices: Invoice[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(invoices));
}
export function saveInvoice(invoice: Invoice) {
  const all = readInvoices();
  const index = all.findIndex((item) => item.id === invoice.id);
  if (index < 0) all.unshift(invoice);
  else all[index] = invoice;
  writeInvoices(all);
}
export function removeInvoice(id: string) {
  writeInvoices(readInvoices().filter((item) => item.id !== id));
}
export function calculateTotal(items: LineItem[]) {
  return items.reduce((sum, item) => sum + Math.max(0, Number(item.quantity) || 0) * Math.max(0, Number(item.unitPrice) || 0), 0);
}
export function money(amount: number, currency = 'USD') {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency, minimumFractionDigits: 2 }).format(amount || 0);
}
export function nextInvoiceNumber(invoices: Invoice[]) {
  const year = new Date().getFullYear();
  const max = invoices.reduce((n, item) => {
    const match = item.invoiceNumber.match(/(\d+)$/);
    return match ? Math.max(n, Number(match[1])) : n;
  }, 0);
  return `INV-${year}-${String(max + 1).padStart(3, '0')}`;
}
