import { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { ArrowUpRight, FilePlus2, RefreshCw, WalletCards, WandSparkles } from 'lucide-react';
import { useGetInvoiceAssistantStatus, useGetPaypalConfig, getGetInvoiceAssistantStatusQueryKey, getGetPaypalConfigQueryKey } from '@workspace/api-client-react';
import { Shell } from '../components/Shell';
import { money, readInvoices, type Invoice } from '../lib/invoices';

function StatusCard({ kind, configured, loading, error, onRetry }: { kind: 'assistant' | 'paypal'; configured?: boolean; loading: boolean; error: boolean; onRetry: () => void }) {
  const ai = kind === 'assistant';
  return <div className="ready-card">
    <div className={`ready-icon ${configured === false || error ? 'warn' : ''}`}>{ai ? <WandSparkles /> : <WalletCards />}</div>
    <div style={{ flex: 1 }}>
      <strong>{ai ? 'AI invoice drafting' : 'PayPal checkout'}</strong>
      <p>{loading ? 'Checking integration readiness…' : error ? 'Could not check connection status. Try again.' : configured ? (ai ? 'Ready to turn your project brief into a first draft.' : 'Sandbox checkout is configured and ready for testing.') : (ai ? 'Add the required AI secret in Replit to enable draft generation.' : 'Add your PayPal sandbox secrets in Replit to enable checkout.')}</p>
      {configured === false && !loading && !error && <p style={{ marginTop: 7, fontWeight: 600 }}>Open Replit Secrets and add the integration credentials, then refresh this status.</p>}
      {error && <button className="button button-quiet" style={{ marginTop: 9, padding: '6px 9px', fontSize: 10 }} onClick={onRetry} data-testid={`button-retry-${kind}`}><RefreshCw size={12} /> Retry check</button>}
    </div>
    {!loading && !error && <span className={`ready-status ${configured ? '' : 'pending'}`}>{configured ? 'Ready' : 'Setup needed'}</span>}
  </div>;
}

export default function Home() {
  const [revision, setRevision] = useState(0);
  const invoices = useMemo(() => readInvoices(), [revision]);
  const assistant = useGetInvoiceAssistantStatus({ query: { queryKey: getGetInvoiceAssistantStatusQueryKey() } });
  const paypal = useGetPaypalConfig({ query: { queryKey: getGetPaypalConfigQueryKey() } });
  const paid = invoices.filter((item) => item.status === 'paid');
  const outstanding = invoices.filter((item) => item.status !== 'paid');
  const outstandingAmount = outstanding.reduce((sum, item) => sum + item.totalAmount, 0);
  return <Shell><div className="content fade-in">
    <div className="page-heading">
      <div><div className="eyebrow">Your billing desk</div><h1>Good work deserves<br />to get paid.</h1><p className="intro">A calm place to shape your project work into invoices your clients can understand.</p></div>
      <Link href="/new" className="button button-primary" data-testid="button-create-invoice"><FilePlus2 /> Create an invoice</Link>
    </div>
    <div className="stats-grid">
      <div className="stat-card featured"><div className="stat-label">Awaiting payment <ArrowUpRight size={15} /></div><div className="stat-value">{money(outstandingAmount)}</div><div className="stat-meta">{outstanding.length} {outstanding.length === 1 ? 'invoice' : 'invoices'} in progress</div></div>
      <div className="stat-card"><div className="stat-label">Collected</div><div className="stat-value">{money(paid.reduce((sum, item) => sum + item.totalAmount, 0))}</div><div className="stat-meta">{paid.length} paid {paid.length === 1 ? 'invoice' : 'invoices'}</div></div>
      <div className="stat-card"><div className="stat-label">Total invoices</div><div className="stat-value">{String(invoices.length).padStart(2, '0')}</div><div className="stat-meta">Saved in this browser</div></div>
    </div>
    <div className="section-head"><h2>Integration readiness</h2><span>LIVE CHECKS</span></div>
    <div className="readiness">
      <StatusCard kind="assistant" configured={assistant.data?.configured} loading={assistant.isLoading} error={assistant.isError} onRetry={() => void assistant.refetch()} />
      <StatusCard kind="paypal" configured={paypal.data?.configured} loading={paypal.isLoading} error={paypal.isError} onRetry={() => void paypal.refetch()} />
    </div>
    <div className="section-head"><h2>Recent invoices</h2><span>{invoices.length ? `${invoices.length} SAVED` : 'LOCAL WORKSPACE'}</span></div>
    {invoices.length ? <div className="invoice-table">
      <div className="table-head"><span>Invoice</span><span>Client</span><span>Due date</span><span>Amount</span><span>Status</span><span /></div>
      {invoices.map((invoice: Invoice) => <Link href={`/invoice/${invoice.id}`} className="invoice-row" key={invoice.id} data-testid={`row-invoice-${invoice.id}`}>
        <span><span className="invoice-title">{invoice.title || 'Untitled invoice'}</span><span className="invoice-id">{invoice.invoiceNumber}</span></span>
        <span>{invoice.clientName}</span><span>{invoice.dueDate ? new Date(`${invoice.dueDate}T00:00:00`).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—'}</span>
        <span style={{ fontFamily: 'var(--app-font-mono)' }}>{money(invoice.totalAmount, invoice.currency)}</span>
        <span><span className={`status-pill ${invoice.status}`}>{invoice.status}</span></span><span className="row-open"><ArrowUpRight /></span>
      </Link>)}
    </div> : <div className="empty-state"><div className="empty-mark"><FilePlus2 /></div><h3>Your first invoice starts here.</h3><p>Describe the work, shape the line items, and save a reviewable invoice right here in your workspace.</p><Link href="/new" className="button button-primary" data-testid="button-empty-create">Create your first invoice</Link></div>}
  </div></Shell>;
}
