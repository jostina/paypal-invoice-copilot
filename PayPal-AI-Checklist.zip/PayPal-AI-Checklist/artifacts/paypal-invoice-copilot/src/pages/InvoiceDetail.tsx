import { useMemo, useState } from 'react';
import { Link, useLocation, useParams } from 'wouter';
import { ArrowLeft, Check, Pencil, Plus, Printer, Trash2 } from 'lucide-react';
import { useGetPaypalConfig, getGetPaypalConfigQueryKey } from '@workspace/api-client-react';
import { Shell } from '../components/Shell';
import { PaypalCheckout } from '../components/PaypalCheckout';
import { calculateTotal, money, readInvoices, removeInvoice, saveInvoice, type Invoice, type LineItem } from '../lib/invoices';

export default function InvoiceDetail() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const paypal = useGetPaypalConfig({ query: { queryKey: getGetPaypalConfigQueryKey() } });
  const [revision, setRevision] = useState(0);
  const invoice = useMemo(() => readInvoices().find((item) => item.id === params.id), [params.id, revision]);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState('');
  const [savedToast, setSavedToast] = useState(false);
  const [form, setForm] = useState<Invoice | null>(null);
  if (!invoice) return <Shell><div className="content"><div className="empty-state"><div className="empty-mark"><ArrowLeft /></div><h3>This invoice isn't here.</h3><p>It may have been removed from this browser. Your saved invoices stay local to this device.</p><Link href="/" className="button button-primary" data-testid="link-return-invoices">Back to invoices</Link></div></div></Shell>;
  const active = editing && form ? form : invoice;
  const total = calculateTotal(active.lineItems);
  const update = (patch: Partial<Invoice>) => setForm((current) => current ? { ...current, ...patch } : { ...invoice, ...patch });
  const updateLine = (index: number, patch: Partial<LineItem>) => update({ lineItems: active.lineItems.map((line, i) => i === index ? { ...line, ...patch } : line) });
  const beginEdit = () => { setForm({ ...invoice, lineItems: invoice.lineItems.map((line) => ({ ...line })) }); setEditing(true); setSavedToast(false); };
  const save = () => {
    if (!form || !form.clientName.trim() || !form.title.trim() || !form.dueDate || form.lineItems.some((item) => !item.description.trim()) || total <= 0) {
      setError('Complete the client, title, due date, and line items. Total must be greater than zero.'); return;
    }
    const updated = { ...form, clientName: form.clientName.trim(), title: form.title.trim(), lineItems: form.lineItems.map((line) => ({ ...line, quantity: Number(line.quantity), unitPrice: Number(line.unitPrice) })), totalAmount: total };
    saveInvoice(updated); setForm(updated); setEditing(false); setError(''); setSavedToast(true); setRevision((n) => n + 1);
  };
  const remove = () => {
    if (window.confirm(`Delete ${invoice.invoiceNumber}? This cannot be undone.`)) {
      removeInvoice(invoice.id); setLocation('/');
    }
  };
  const paid = (paidAt: string) => {
    const updated = { ...readInvoices().find((item) => item.id === invoice.id)!, status: 'paid' as const, paidAt };
    saveInvoice(updated); setRevision((n) => n + 1);
  };
  const orderCreated = (orderId: string) => {
    const current = readInvoices().find((item) => item.id === invoice.id);
    if (!current) return;
    saveInvoice({ ...current, paypalOrderId: orderId, status: 'sent' }); setRevision((n) => n + 1);
  };
  return <Shell><div className="content fade-in">
    <div className="detail-head">
      <div><Link href="/" className="crumb" data-testid="link-back-invoices"><ArrowLeft size={13} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 6 }} />All invoices</Link>
        <div className="eyebrow" style={{ marginTop: 20 }}>{active.invoiceNumber} · {editing ? 'Editing' : active.status}</div>
        <h1>{editing ? 'Shape the details.' : active.title}</h1>
        {!editing && <p className="intro">Invoice for {active.clientName} · Due {new Date(`${active.dueDate}T00:00:00`).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>}
      </div>
      <div className="detail-actions">
        {!editing ? <><button className="button button-quiet" onClick={() => window.print()} data-testid="button-print-invoice"><Printer /> Print</button><button className="button button-quiet" onClick={beginEdit} disabled={active.status === 'paid'} data-testid="button-edit-invoice"><Pencil /> Edit</button><button className="button button-danger" onClick={remove} data-testid="button-delete-invoice"><Trash2 /></button></> :
          <><button className="button button-quiet" onClick={() => { setEditing(false); setForm(null); setError(''); }} data-testid="button-cancel-edit">Cancel</button><button className="button button-primary" onClick={save} data-testid="button-save-edit"><Check /> Save changes</button></>}
      </div>
    </div>
    {error && <div className="alert alert-error" role="alert" data-testid="status-detail-error">{error}</div>}
    {savedToast && <div className="alert alert-info" role="status">Your changes are saved in this browser.</div>}
    <article className="invoice-paper">
      <div className="paper-top"><div><div className="paper-label">Invoice</div><div style={{ fontFamily: 'var(--app-font-serif)', fontSize: 35, marginTop: 10, letterSpacing: '-.04em' }}>For good work.</div></div><div className="paper-number">{active.invoiceNumber}<br />Created {new Date(active.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}<br /><span className={`status-pill ${active.status}`} style={{ marginTop: 9 }}>{active.status}</span></div></div>
      <div className="bill-to">Bill to</div>
      {editing ? <div className="field-grid" style={{ maxWidth: 650 }}>
        <div className="field"><label>Client name</label><input value={active.clientName} onChange={(e) => update({ clientName: e.target.value })} data-testid="input-edit-client" /></div>
        <div className="field"><label>Invoice title</label><input value={active.title} onChange={(e) => update({ title: e.target.value })} data-testid="input-edit-title" /></div>
        <div className="field"><label>Due date</label><input type="date" value={active.dueDate} onChange={(e) => update({ dueDate: e.target.value })} data-testid="input-edit-due-date" /></div>
        <div className="field"><label>Payment terms</label><input value={active.paymentTerms} onChange={(e) => update({ paymentTerms: e.target.value })} data-testid="input-edit-terms" /></div>
      </div> : <><div className="bill-name">{active.clientName}</div><div className="preview-meta">{active.title}<br />{active.paymentTerms}</div></>}
      <table className="detail-lines"><thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th>{editing && <th />}</tr></thead><tbody>{active.lineItems.map((item, index) => <tr key={index}>
        <td>{editing ? <input className="line-input" value={item.description} onChange={(e) => updateLine(index, { description: e.target.value })} aria-label="Edit line description" data-testid={`input-edit-line-desc-${index}`} /> : item.description}</td>
        <td>{editing ? <input className="line-input" type="number" min=".01" step=".25" value={item.quantity} onChange={(e) => updateLine(index, { quantity: Number(e.target.value) })} aria-label="Edit quantity" data-testid={`input-edit-line-qty-${index}`} /> : item.quantity}</td>
        <td>{editing ? <input className="line-input" type="number" min="0" step=".01" value={item.unitPrice} onChange={(e) => updateLine(index, { unitPrice: Number(e.target.value) })} aria-label="Edit rate" data-testid={`input-edit-line-rate-${index}`} /> : money(item.unitPrice)}</td>
        <td>{money(item.quantity * item.unitPrice)}</td>
        {editing && <td><button className="remove-line" aria-label="Remove line item" onClick={() => update({ lineItems: active.lineItems.length > 1 ? active.lineItems.filter((_, i) => i !== index) : active.lineItems })} data-testid={`button-delete-detail-line-${index}`}><Trash2 /></button></td>}
      </tr>)}</tbody></table>
      {editing && <button className="add-line" onClick={() => update({ lineItems: [...active.lineItems, { description: '', quantity: 1, unitPrice: 0 }] })} data-testid="button-add-detail-line"><Plus /> Add a line item</button>}
      <div className="detail-total"><span>Total due</span><strong>{money(total, active.currency)}</strong></div>
      {editing ? <div className="field" style={{ maxWidth: 520 }}><label>Note to client</label><textarea value={active.note} onChange={(e) => update({ note: e.target.value })} data-testid="input-edit-note" /></div> : active.note && <p className="preview-note">{active.note}</p>}
    </article>
    {active.status === 'paid' ? <div className="payment-box"><div className="paid-banner">Payment confirmed · {active.paidAt ? new Date(active.paidAt).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' }) : 'Paid'}</div></div> :
      <div className="payment-box"><h3>Ready to collect?</h3><p>PayPal sandbox checkout. Approve the payment in PayPal to confirm capture; this invoice changes to paid only after a completed capture response.</p>
        {paypal.isLoading ? <div className="loading-skeleton" style={{ width: 220, height: 38 }} aria-label="Checking PayPal configuration" /> :
          paypal.isError ? <div className="alert alert-error" role="alert">Could not check PayPal setup. <button className="button button-quiet" onClick={() => void paypal.refetch()} data-testid="button-retry-paypal">Retry status</button></div> :
          !paypal.data?.configured || !paypal.data.clientId ? <div className="alert alert-info" role="status">PayPal checkout is not configured. Add the PayPal sandbox client ID and secret in Replit Secrets to enable payment.</div> :
          <PaypalCheckout key={active.totalAmount} invoice={{ ...active, totalAmount: total }} clientId={paypal.data.clientId} onPaid={paid} onOrderCreated={orderCreated} />}
        <p className="notice">This is a sandbox transaction. A real payment is never assumed from approval alone.</p>
      </div>}
  </div></Shell>;
}
