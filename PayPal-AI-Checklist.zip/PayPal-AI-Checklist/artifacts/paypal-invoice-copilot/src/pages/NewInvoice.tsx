import { useMemo, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { ArrowLeft, Plus, Sparkles, Trash2 } from 'lucide-react';
import { useCreateInvoiceDraft, useGetInvoiceAssistantStatus, getGetInvoiceAssistantStatusQueryKey } from '@workspace/api-client-react';
import { Shell } from '../components/Shell';
import { calculateTotal, nextInvoiceNumber, readInvoices, saveInvoice, type LineItem } from '../lib/invoices';

export default function NewInvoice() {
  const [, setLocation] = useLocation();
  const assistant = useGetInvoiceAssistantStatus({ query: { queryKey: getGetInvoiceAssistantStatusQueryKey() } });
  const createDraft = useCreateInvoiceDraft();
  const existing = useMemo(() => readInvoices(), []);
  const [clientName, setClientName] = useState('');
  const [workDescription, setWorkDescription] = useState('');
  const [title, setTitle] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('Due within 14 days');
  const [note, setNote] = useState('');
  const [lineItems, setLineItems] = useState<LineItem[]>([{ description: '', quantity: 1, unitPrice: 0 }]);
  const [error, setError] = useState('');
  const total = calculateTotal(lineItems);
  const updateLine = (index: number, patch: Partial<LineItem>) => setLineItems((items) => items.map((item, i) => i === index ? { ...item, ...patch } : item));
  const generate = () => {
    setError('');
    if (!assistant.data?.configured) {
      setError(assistant.isError ? 'The AI integration status could not be checked. Retry the status check before drafting.' : 'AI drafting is unavailable until the required secret is added in Replit.');
      return;
    }
    if (clientName.trim().length < 1 || workDescription.trim().length < 8 || !dueDate || total <= 0) {
      setError('Add a client, a project description of at least 8 characters, an amount, and a due date before asking for a draft.');
      return;
    }
    createDraft.mutate({ data: { clientName: clientName.trim(), workDescription: workDescription.trim(), totalAmount: total, currency: 'USD', dueDate } }, {
      onSuccess: (draft) => {
        setTitle(draft.title);
        setLineItems(draft.lineItems.map((line) => ({ description: line.description, quantity: line.quantity, unitPrice: line.unitPrice })));
        setPaymentTerms(draft.paymentTerms);
        setNote(draft.note);
      },
      onError: () => setError('The invoice assistant could not create a draft. Check the integration setup and try again.'),
    });
  };
  const save = () => {
    if (!clientName.trim() || !title.trim() || !dueDate || lineItems.some((item) => !item.description.trim()) || total <= 0) {
      setError('Complete the client, invoice title, due date, and each line item. The total must be greater than zero.');
      return;
    }
    const invoice = {
      id: globalThis.crypto?.randomUUID?.() ?? `invoice-${Date.now()}`,
      invoiceNumber: nextInvoiceNumber(existing),
      clientName: clientName.trim(),
      title: title.trim(),
      lineItems: lineItems.map((item) => ({ ...item, description: item.description.trim(), quantity: Number(item.quantity), unitPrice: Number(item.unitPrice) })),
      totalAmount: total,
      currency: 'USD' as const,
      dueDate,
      paymentTerms: paymentTerms.trim(),
      note: note.trim(),
      status: 'draft' as const,
      createdAt: new Date().toISOString(),
    };
    saveInvoice(invoice);
    setLocation(`/invoice/${invoice.id}`);
  };
  return <Shell><div className="content fade-in">
    <div className="eyebrow">Create / new invoice</div>
    <div className="page-heading" style={{ marginBottom: 28 }}>
      <div><h1>Make the work<br />easy to understand.</h1><p className="intro">Start with the project details. Your draft stays yours to review and edit before sharing.</p></div>
      <Link href="/" className="button button-quiet" data-testid="link-back-overview"><ArrowLeft /> Overview</Link>
    </div>
    {assistant.isError && <div className="alert alert-error" role="alert">Could not check AI assistant readiness. You can still write and save an invoice manually. <button className="button button-quiet" onClick={() => void assistant.refetch()} data-testid="button-retry-assistant">Retry</button></div>}
    {error && <div className="alert alert-error" role="alert" data-testid="status-form-error">{error}</div>}
    {createDraft.isSuccess && <div className="alert alert-info" role="status">Draft received. Review every detail below before saving.</div>}
    <div className="form-layout">
      <section>
        <div className="form-card">
          <h2>Project brief</h2><p className="form-helper">When you request an AI draft, the client name, project notes, amount, and due date are sent to OpenAI. Avoid sensitive client details; review the editable result before using it.</p>
          <div className="field-grid">
            <div className="field"><label htmlFor="client-name">Client name</label><input id="client-name" value={clientName} onChange={(e) => setClientName(e.target.value)} placeholder="e.g. Northstar Studio" data-testid="input-client-name" /></div>
            <div className="field"><label htmlFor="due-date">Due date</label><input id="due-date" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} data-testid="input-due-date" /></div>
          </div>
          <div className="field"><label htmlFor="project-brief">What did you work on?</label><textarea id="project-brief" value={workDescription} onChange={(e) => setWorkDescription(e.target.value)} placeholder="Describe the project, deliverables, and any milestones…" data-testid="input-work-description" /></div>
          <div className="field" style={{ maxWidth: 230 }}><label htmlFor="estimate">Estimated total (USD)</label><input id="estimate" type="number" min="0.01" step="0.01" value={total || ''} onChange={(e) => setLineItems((items) => items.map((item, index) => index === 0 ? { ...item, unitPrice: Number(e.target.value) } : item))} placeholder="0.00" data-testid="input-estimated-total" /></div>
          <button className="button button-primary" onClick={generate} disabled={createDraft.isPending || assistant.isLoading || !assistant.data?.configured} data-testid="button-generate-draft"><Sparkles />{createDraft.isPending ? 'Preparing draft…' : 'Draft with AI'}</button>
          {!assistant.isLoading && !assistant.isError && !assistant.data?.configured && <p className="notice">AI drafting is not configured. Add the required secret in Replit to enable this step. You can still build an invoice manually below.</p>}
        </div>
        <div className="form-card">
          <h2>Review your invoice</h2><p className="form-helper">Edit line items freely. Amounts are calculated from quantity × unit price.</p>
          <div className="field"><label htmlFor="invoice-title">Invoice title</label><input id="invoice-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Website design — phase one" data-testid="input-invoice-title" /></div>
          <div className="field-grid">
            <div className="field"><label htmlFor="terms">Payment terms</label><input id="terms" value={paymentTerms} onChange={(e) => setPaymentTerms(e.target.value)} placeholder="Due within 14 days" data-testid="input-payment-terms" /></div>
            <div className="field"><label htmlFor="invoice-note">Note to client</label><input id="invoice-note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Thank you for your partnership." data-testid="input-invoice-note" /></div>
          </div>
          <div className="line-header"><span>Description</span><span>Qty</span><span>Rate</span><span style={{ textAlign: 'right' }}>Amount</span><span /></div>
          {lineItems.map((item, index) => <div className="line-row" key={index}>
            <input className="line-input" aria-label={`Line ${index + 1} description`} value={item.description} onChange={(e) => updateLine(index, { description: e.target.value })} placeholder="Service or deliverable" data-testid={`input-line-description-${index}`} />
            <input className="line-input" aria-label={`Line ${index + 1} quantity`} type="number" min="0.01" step="0.25" value={item.quantity} onChange={(e) => updateLine(index, { quantity: Number(e.target.value) })} data-testid={`input-line-quantity-${index}`} />
            <input className="line-input" aria-label={`Line ${index + 1} rate`} type="number" min="0" step="0.01" value={item.unitPrice} onChange={(e) => updateLine(index, { unitPrice: Number(e.target.value) })} data-testid={`input-line-rate-${index}`} />
            <span className="line-total">{(item.quantity * item.unitPrice).toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</span>
            <button className="remove-line" aria-label="Remove line item" onClick={() => setLineItems((items) => items.length > 1 ? items.filter((_, i) => i !== index) : items)} data-testid={`button-remove-line-${index}`}><Trash2 /></button>
          </div>)}
          <button className="add-line" onClick={() => setLineItems((items) => [...items, { description: '', quantity: 1, unitPrice: 0 }])} data-testid="button-add-line"><Plus /> Add a line item</button>
          <div className="totals"><span>Total due · USD</span><strong>{total.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</strong></div>
          <div className="form-actions"><Link href="/" className="button button-quiet" data-testid="button-cancel-invoice">Cancel</Link><button className="button button-primary" onClick={save} data-testid="button-save-invoice">Save invoice</button></div>
        </div>
      </section>
      <aside className="preview-card">
        <div className="preview-top"><small>Live preview</small></div>
        <div className="preview-paper"><h3>{title || 'Your invoice title'}</h3><div className="preview-meta">{clientName || 'Client name'}<br />Due {dueDate ? new Date(`${dueDate}T00:00:00`).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) : 'Choose a due date'}<br />{paymentTerms}</div>
          <div className="preview-lines">{lineItems.map((item, i) => <div className="preview-line" key={i}><span>{item.description || 'Line item'}</span><span>{(item.quantity * item.unitPrice).toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</span></div>)}</div>
          <div className="preview-total"><span>Total due</span><strong>{total.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</strong></div>
          {note && <p className="preview-note">{note}</p>}
        </div>
      </aside>
    </div>
  </div></Shell>;
}
