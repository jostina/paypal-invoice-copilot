# PayPal Invoice Copilot — 90-second demo

**0:00–0:10 — The problem**  
“Freelancers lose time turning project notes into invoices and then chasing payment. PayPal Invoice Copilot drafts the invoice and gives the client a direct PayPal checkout.”

**0:10–0:30 — AI drafting**  
Open **New invoice**, enter a client, describe the completed work, choose a total and due date, then select **Draft with AI**. Show the generated title, service description, terms, and note. Mention that the draft is editable and must be reviewed.

**0:30–0:50 — Review and save**  
Edit the invoice line item and payment terms, save it, and return to the invoice list. Show that the draft remains available after reloading the page.

**0:50–1:15 — PayPal Sandbox**  
Open the invoice and start PayPal Sandbox checkout. Approve using a PayPal sandbox buyer account. Show the confirmed capture status and the invoice marked paid.

**1:15–1:30 — Trust and setup**  
Point out that AI and PayPal credentials stay in Replit Secrets, and that the payment flow is sandbox-only. Close on the invoice list.

Keep the recording under 3 minutes. Do not show secret values or real client data.
