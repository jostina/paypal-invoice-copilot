# PayPal Invoice Copilot

An AI invoice drafting demo for freelancers with PayPal Sandbox checkout.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/paypal-invoice-copilot` — web app and browser-local invoice storage.
- `artifacts/api-server/src/routes/invoice-assistant.ts` — OpenAI-powered draft endpoint.
- `artifacts/api-server/src/routes/paypal.ts` — PayPal Sandbox order and capture endpoints.
- `lib/api-spec/openapi.yaml` — API source contract; regenerate clients after edits.

## Architecture decisions

- Invoices are stored in browser local storage; no user account or shared invoice database is required for the demo.
- PayPal server credentials stay in Replit Secrets; the payment API is sandbox-only.
- AI and payment endpoints fail explicitly when their secrets are missing; there are no simulated successful responses.

## Product

Freelancers can draft, edit, save, and pay invoices. AI produces editable invoice wording from project notes, and PayPal Sandbox provides order creation and capture for the payment demonstration.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
